import React from 'react';
import { cn } from '../lib/utils';
import { AnimationLevel } from '../types';

interface XsheetProps {
  levels: AnimationLevel[];
  currentFrame: number;
  currentLevelId: string;
  onSelectFrame: (frameIndex: number, levelId: string) => void;
}

export const Xsheet: React.FC<XsheetProps> = ({
  levels,
  currentFrame,
  currentLevelId,
  onSelectFrame,
}) => {
  const framesCount = 100;

  return (
    <div className="flex flex-col h-full bg-[#1c1c1c] border-l border-[#27272a] overflow-hidden">
      <div className="p-2 border-bottom border-[#27272a] bg-[#27272a] text-[10px] font-bold uppercase tracking-wider text-zinc-500">
        Exposure Sheet (Xsheet)
      </div>
      
      <div className="flex-1 overflow-auto">
        <div className="relative">
          {/* Header */}
          <div className="flex sticky top-0 z-10 bg-[#1c1c1c]">
            <div className="w-10 h-8 border-r border-b border-[#27272a] flex items-center justify-center text-[10px] font-mono text-zinc-500">
              #
            </div>
            {levels.map((level) => (
              <div 
                key={level.id}
                className="flex-1 min-w-[100px] h-8 border-r border-b border-[#27272a] flex items-center justify-center text-[10px] font-bold truncate px-2"
              >
                {level.name}
              </div>
            ))}
          </div>

          {/* Grid */}
          {Array.from({ length: framesCount }).map((_, frameIdx) => (
            <div key={frameIdx} className="flex">
              <div className={cn(
                "w-10 h-6 border-r border-b border-[#27272a] flex items-center justify-center text-[10px] font-mono",
                currentFrame === frameIdx ? "bg-blue-600 text-white" : "text-zinc-500"
              )}>
                {frameIdx + 1}
              </div>
              {levels.map((level) => {
                const drawingId = level.frames[frameIdx];
                const isActive = currentFrame === frameIdx && currentLevelId === level.id;
                
                return (
                  <div
                    key={level.id}
                    onClick={() => onSelectFrame(frameIdx, level.id)}
                    className={cn(
                      "flex-1 min-w-[100px] h-6 border-r border-b border-[#27272a] flex items-center justify-center text-[10px] cursor-pointer transition-colors",
                      isActive ? "bg-blue-900/40 border-blue-500" : "hover:bg-zinc-800",
                      drawingId ? "text-blue-400 font-bold" : "text-zinc-700"
                    )}
                  >
                    {drawingId ? drawingId.split('-')[1] : '—'}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
