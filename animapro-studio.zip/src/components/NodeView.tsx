import React from 'react';
import ReactFlow, { 
  Background, 
  Controls, 
  MiniMap,
  Handle,
  Position,
  NodeProps
} from 'reactflow';
import 'reactflow/dist/style.css';

const EffectNode = ({ data }: NodeProps) => {
  return (
    <div className="px-4 py-2 shadow-md rounded-md bg-[#27272a] border border-[#3f3f46] text-white min-w-[120px]">
      <Handle type="target" position={Position.Left} className="w-2 h-2 bg-blue-500" />
      <div className="flex flex-col">
        <div className="text-[10px] font-bold uppercase text-zinc-500 mb-1">{data.type}</div>
        <div className="text-xs">{data.label}</div>
      </div>
      <Handle type="source" position={Position.Right} className="w-2 h-2 bg-blue-500" />
    </div>
  );
};

const nodeTypes = {
  effect: EffectNode,
};

const initialNodes = [
  {
    id: '1',
    type: 'effect',
    data: { label: 'Character Level', type: 'Input' },
    position: { x: 50, y: 50 },
  },
  {
    id: '2',
    type: 'effect',
    data: { label: 'Glow Effect', type: 'Filter' },
    position: { x: 250, y: 50 },
  },
  {
    id: '3',
    type: 'effect',
    data: { label: 'Final Output', type: 'Output' },
    position: { x: 450, y: 50 },
  },
];

const initialEdges = [
  { id: 'e1-2', source: '1', target: '2', animated: true },
  { id: 'e2-3', source: '2', target: '3' },
];

export const NodeView: React.FC = () => {
  return (
    <div className="w-full h-full bg-[#121212]">
      <ReactFlow
        nodes={initialNodes}
        edges={initialEdges}
        nodeTypes={nodeTypes}
        fitView
      >
        <Background color="#333" gap={20} />
        <Controls />
        <MiniMap 
          nodeColor={(n) => '#3b82f6'}
          maskColor="rgba(0, 0, 0, 0.1)"
          style={{ backgroundColor: '#1c1c1c' }}
        />
      </ReactFlow>
    </div>
  );
};
