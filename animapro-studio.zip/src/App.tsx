/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useMemo } from 'react';
import { 
  Pencil, 
  Eraser, 
  PaintBucket, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Layers, 
  Settings, 
  Download, 
  Share2,
  Box,
  Zap,
  Eye,
  EyeOff,
  Plus
} from 'lucide-react';
import { CanvasEngine } from './components/CanvasEngine';
import { Xsheet } from './components/Xsheet';
import { PaletteManager } from './components/PaletteManager';
import { NodeView } from './components/NodeView';
import { PropertiesPanel } from './components/PropertiesPanel';
import { SceneState, DrawingStroke, ColorPalette, Drawing } from './types';
import { cn } from './lib/utils';
import { motion, AnimatePresence } from 'motion/react';

const INITIAL_PALETTE: ColorPalette = {
  'ink': { name: 'Ink', color: '#000000' },
  'skin': { name: 'Skin', color: '#ffdbac' },
  'hair': { name: 'Hair', color: '#4b2c20' },
  'clothes': { name: 'Clothes', color: '#3b82f6' },
};

export default function App() {
  const [state, setState] = useState<SceneState>({
    currentFrame: 0,
    currentLevelId: 'level-1',
    palette: INITIAL_PALETTE,
    drawings: {
      'draw-1': { id: 'draw-1', strokes: [] }
    },
    levels: [
      { id: 'level-1', name: 'Character', frames: { 0: 'draw-1' } },
      { id: 'level-2', name: 'Background', frames: {} }
    ]
  });

  const [tool, setTool] = useState<'brush' | 'eraser' | 'fill'>('brush');
  const [activeColorId, setActiveColorId] = useState('ink');
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState<'canvas' | 'schematic'>('canvas');
  const [showOnionSkin, setShowOnionSkin] = useState(true);

  // Animation Playback
  React.useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setState(prev => ({
          ...prev,
          currentFrame: (prev.currentFrame + 1) % 24
        }));
      }, 1000 / 12); // 12 FPS
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const currentDrawingId = state.levels.find(l => l.id === state.currentLevelId)?.frames[state.currentFrame];
  const currentDrawing = currentDrawingId ? state.drawings[currentDrawingId] : { id: 'empty', strokes: [] };

  const handleDrawingUpdate = useCallback((strokes: DrawingStroke[]) => {
    setState(prev => {
      let drawingId = prev.levels.find(l => l.id === prev.currentLevelId)?.frames[prev.currentFrame];
      
      if (!drawingId) {
        drawingId = `draw-${Date.now()}`;
        const newLevels = prev.levels.map(l => {
          if (l.id === prev.currentLevelId) {
            return { ...l, frames: { ...l.frames, [prev.currentFrame]: drawingId! } };
          }
          return l;
        });
        
        return {
          ...prev,
          levels: newLevels,
          drawings: {
            ...prev.drawings,
            [drawingId]: { id: drawingId, strokes }
          }
        };
      }

      return {
        ...prev,
        drawings: {
          ...prev.drawings,
          [drawingId]: { ...prev.drawings[drawingId], strokes }
        }
      };
    });
  }, [state.currentFrame, state.currentLevelId]);

  const handleAddColor = () => {
    const id = `color-${Date.now()}`;
    setState(prev => ({
      ...prev,
      palette: {
        ...prev.palette,
        [id]: { name: 'New Color', color: '#cccccc' }
      }
    }));
    setActiveColorId(id);
  };

  const handleUpdateColor = (id: string, color: string) => {
    setState(prev => ({
      ...prev,
      palette: {
        ...prev.palette,
        [id]: { ...prev.palette[id], color }
      }
    }));
  };

  const onionSkinPrev = useMemo(() => {
    if (!showOnionSkin || state.currentFrame === 0) return undefined;
    const prevDrawingId = state.levels.find(l => l.id === state.currentLevelId)?.frames[state.currentFrame - 1];
    return prevDrawingId ? state.drawings[prevDrawingId] : undefined;
  }, [state.currentFrame, state.currentLevelId, state.drawings, showOnionSkin]);

  const onionSkinNext = useMemo(() => {
    if (!showOnionSkin) return undefined;
    const nextDrawingId = state.levels.find(l => l.id === state.currentLevelId)?.frames[state.currentFrame + 1];
    return nextDrawingId ? state.drawings[nextDrawingId] : undefined;
  }, [state.currentFrame, state.currentLevelId, state.drawings, showOnionSkin]);

  return (
    <div className="flex h-screen w-screen bg-[#0a0a0a] text-zinc-300 font-sans selection:bg-blue-500/30">
      {/* Left Toolbar */}
      <aside className="w-14 bg-[#1c1c1c] border-r border-[#27272a] flex flex-col items-center py-4 gap-4 z-50">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-900/20 mb-4">
          <Zap size={20} fill="currentColor" />
        </div>
        
        <div className="flex flex-col gap-2">
          <ToolButton 
            active={tool === 'brush'} 
            onClick={() => setTool('brush')}
            icon={<Pencil size={18} />}
            label="Brush (B)"
          />
          <ToolButton 
            active={tool === 'eraser'} 
            onClick={() => { setTool('eraser'); setActiveColorId('eraser'); }}
            icon={<Eraser size={18} />}
            label="Eraser (E)"
          />
          <ToolButton 
            active={tool === 'fill'} 
            onClick={() => setTool('fill')}
            icon={<PaintBucket size={18} />}
            label="Fill (F)"
          />
        </div>

        <div className="mt-auto flex flex-col gap-2">
          <ToolButton 
            active={showOnionSkin} 
            onClick={() => setShowOnionSkin(!showOnionSkin)}
            icon={showOnionSkin ? <Eye size={18} /> : <EyeOff size={18} />}
            label="Onion Skin (O)"
          />
          <ToolButton icon={<Settings size={18} />} label="Settings" />
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header / Tabs */}
        <header className="h-12 bg-[#1c1c1c] border-b border-[#27272a] flex items-center px-4 justify-between">
          <div className="flex gap-4 items-center">
            <h1 className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-500">AnimaPro Studio</h1>
            <div className="h-4 w-[1px] bg-zinc-800 mx-2" />
            <div className="flex bg-[#0a0a0a] rounded-lg p-1 gap-1">
              <TabButton 
                active={activeTab === 'canvas'} 
                onClick={() => setActiveTab('canvas')}
                label="Drawing Canvas"
                icon={<Pencil size={14} />}
              />
              <TabButton 
                active={activeTab === 'schematic'} 
                onClick={() => setActiveTab('schematic')}
                label="Schematic View"
                icon={<Box size={14} />}
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-[#0a0a0a] px-3 py-1.5 rounded-full border border-[#27272a]">
              <button onClick={() => setState(s => ({ ...s, currentFrame: Math.max(0, s.currentFrame - 1) }))} className="hover:text-blue-400">
                <SkipBack size={14} />
              </button>
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center transition-all",
                  isPlaying ? "bg-red-500 text-white" : "bg-blue-600 text-white hover:scale-105"
                )}
              >
                {isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
              </button>
              <button onClick={() => setState(s => ({ ...s, currentFrame: s.currentFrame + 1 }))} className="hover:text-blue-400">
                <SkipForward size={14} />
              </button>
              <span className="text-[10px] font-mono w-12 text-center text-zinc-500">
                FR: {(state.currentFrame + 1).toString().padStart(3, '0')}
              </span>
            </div>
            
            <div className="flex gap-2">
              <button className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-400 transition-colors">
                <Share2 size={18} />
              </button>
              <button className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all">
                <Download size={16} />
                Render
              </button>
            </div>
          </div>
        </header>

        {/* Workspace */}
        <div className="flex-1 flex min-h-0">
          <div className="flex-1 relative">
            <AnimatePresence mode="wait">
              {activeTab === 'canvas' ? (
                <motion.div 
                  key="canvas"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full h-full"
                >
                  <CanvasEngine 
                    drawing={currentDrawing}
                    palette={state.palette}
                    onDrawingUpdate={handleDrawingUpdate}
                    tool={tool}
                    activeColorId={activeColorId}
                    onionSkinPrev={onionSkinPrev}
                    onionSkinNext={onionSkinNext}
                  />
                </motion.div>
              ) : (
                <motion.div 
                  key="schematic"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full h-full"
                >
                  <NodeView />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Right Panel: Xsheet */}
          <div className="w-80 flex flex-col border-l border-[#27272a]">
            <div className="h-64">
              <PropertiesPanel />
            </div>
            <div className="flex-1 min-h-0">
              <Xsheet 
                levels={state.levels}
                currentFrame={state.currentFrame}
                currentLevelId={state.currentLevelId}
                onSelectFrame={(idx, lid) => setState(s => ({ ...s, currentFrame: idx, currentLevelId: lid }))}
              />
            </div>
            <div className="h-48">
              <PaletteManager 
                palette={state.palette}
                activeColorId={activeColorId}
                onSelectColor={setActiveColorId}
                onUpdateColor={handleUpdateColor}
                onAddColor={handleAddColor}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function ToolButton({ active, onClick, icon, label }: { active?: boolean, onClick?: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      title={label}
      className={cn(
        "w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200",
        active 
          ? "bg-blue-600/20 text-blue-400 border border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.2)]" 
          : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800"
      )}
    >
      {icon}
    </button>
  );
}

function TabButton({ active, onClick, label, icon }: { active: boolean, onClick: () => void, label: string, icon: React.ReactNode }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-2 px-4 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
        active 
          ? "bg-[#1c1c1c] text-white shadow-sm" 
          : "text-zinc-500 hover:text-zinc-300"
      )}
    >
      {icon}
      {label}
    </button>
  );
}
