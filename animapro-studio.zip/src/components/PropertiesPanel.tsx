import React from 'react';
import { Settings2, Sliders, Activity } from 'lucide-react';

export const PropertiesPanel: React.FC = () => {
  return (
    <div className="flex flex-col h-full bg-[#1c1c1c] border-b border-[#27272a]">
      <div className="p-2 bg-[#27272a] text-[10px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-2">
        <Settings2 size={12} />
        <span>Tool Properties</span>
      </div>
      
      <div className="p-4 space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-[10px] uppercase text-zinc-500">
            <span>Brush Size</span>
            <span>3px</span>
          </div>
          <input type="range" className="w-full accent-blue-500" min="1" max="50" defaultValue="3" />
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-[10px] uppercase text-zinc-500">
            <span>Smoothing</span>
            <span>0.5</span>
          </div>
          <input type="range" className="w-full accent-blue-500" min="0" max="1" step="0.1" defaultValue="0.5" />
        </div>

        <div className="pt-4 border-t border-[#27272a] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase text-zinc-500">Auto-Close Gaps</span>
            <div className="w-8 h-4 bg-blue-600 rounded-full relative">
              <div className="absolute right-1 top-1 w-2 h-2 bg-white rounded-full" />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase text-zinc-500">Smart Scan</span>
            <button className="text-[10px] bg-zinc-800 hover:bg-zinc-700 px-2 py-1 rounded border border-zinc-700">Run</button>
          </div>
        </div>
      </div>
    </div>
  );
};
