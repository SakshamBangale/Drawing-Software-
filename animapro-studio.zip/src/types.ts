export interface ColorPalette {
  [id: string]: {
    name: string;
    color: string;
  };
}

export interface DrawingStroke {
  points: number[];
  colorId: string;
  width: number;
}

export interface AnimationFrame {
  id: string;
  strokes: DrawingStroke[];
}

export interface AnimationLevel {
  id: string;
  name: string;
  frames: { [frameIndex: number]: string }; // frameIndex -> drawingId
}

export interface Drawing {
  id: string;
  strokes: DrawingStroke[];
}

export interface SceneState {
  currentFrame: number;
  currentLevelId: string;
  palette: ColorPalette;
  drawings: { [id: string]: Drawing };
  levels: AnimationLevel[];
}
