import React from 'react';
import { ColorPalette } from '../types';
import { Plus, Trash2 } from 'lucide-react';

interface PaletteManagerProps {
  palette: ColorPalette;
  activeColorId: string;
  onSelectColor: (id: string) => void;
  onUpdateColor: (id: string, color: string) => void;
  onAddColor: () => void;
}

export const PaletteManager: React.FC<PaletteManagerProps> = ({
  palette,
  activeColorId,
  onSelectColor,
  onUpdateColor,
  onAddColor,
}) => {
  return (
    <div className="flex flex-col h-full bg-[#1c1c1c] border-t border-[#27272a]">
      <div className="p-2 bg-[#27272a] text-[10px] font-bold uppercase tracking-wider text-zinc-500 flex justify-between items-center">
        <span>Color Palette</span>
        <button 
          onClick={onAddColor}
          className="p-1 hover:bg-zinc-700 rounded transition-colors"
        >
          <Plus size={12} />
        </button>
      </div>
      
      <div className="flex-1 p-2 overflow-y-auto grid grid-cols-4 gap-2 content-start">
        {Object.entries(palette).map(([id, item]) => (
          <div 
            key={id}
            onClick={() => onSelectColor(id)}
            className={`
              group relative aspect-square rounded cursor-pointer border-2 transition-all
              ${activeColorId === id ? 'border-blue-500 scale-105 shadow-lg' : 'border-transparent hover:border-zinc-600'}
            `}
            style={{ backgroundColor: item.color }}
            title={item.name}
          >
            <input 
              type="color" 
              value={item.color}
              onChange={(e) => onUpdateColor(id, e.target.value)}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <div className="absolute -bottom-4 left-0 right-0 text-[8px] text-center truncate text-zinc-500 opacity-0 group-hover:opacity-100">
              {item.name}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
