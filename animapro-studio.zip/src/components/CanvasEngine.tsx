import React, { useState, useRef, useEffect } from 'react';
import { Stage, Layer, Line, Rect } from 'react-konva';
import { Drawing, DrawingStroke, ColorPalette } from '../types';

interface CanvasEngineProps {
  drawing: Drawing;
  palette: ColorPalette;
  onDrawingUpdate: (strokes: DrawingStroke[]) => void;
  tool: 'brush' | 'eraser' | 'fill';
  activeColorId: string;
  onionSkinPrev?: Drawing;
  onionSkinNext?: Drawing;
}

export const CanvasEngine: React.FC<CanvasEngineProps> = ({
  drawing,
  palette,
  onDrawingUpdate,
  tool,
  activeColorId,
  onionSkinPrev,
  onionSkinNext,
}) => {
  const [isDrawing, setIsDrawing] = useState(false);
  const stageRef = useRef<any>(null);

  const handleMouseDown = (e: any) => {
    setIsDrawing(true);
    const pos = e.target.getStage().getPointerPosition();
    const newStroke: DrawingStroke = {
      points: [pos.x, pos.y],
      colorId: activeColorId,
      width: tool === 'eraser' ? 20 : 3,
    };
    onDrawingUpdate([...drawing.strokes, newStroke]);
  };

  const handleMouseMove = (e: any) => {
    if (!isDrawing) return;

    const stage = e.target.getStage();
    const point = stage.getPointerPosition();
    const lastStroke = drawing.strokes[drawing.strokes.length - 1];
    
    // Update the last stroke's points
    const updatedStrokes = [...drawing.strokes];
    const updatedLastStroke = {
      ...lastStroke,
      points: lastStroke.points.concat([point.x, point.y]),
    };
    updatedStrokes[updatedStrokes.length - 1] = updatedLastStroke;
    onDrawingUpdate(updatedStrokes);
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  return (
    <div className="w-full h-full bg-[#1e1e1e] relative overflow-hidden flex items-center justify-center">
      {/* Grid Background */}
      <div 
        className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)',
          backgroundSize: '20px 20px'
        }}
      />
      
      <Stage
        width={800}
        height={600}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        ref={stageRef}
        className="bg-white shadow-2xl"
      >
        <Layer>
          {/* Background for the "paper" */}
          <Rect width={800} height={600} fill="white" />
          
          {/* Onion Skin Previous */}
          {onionSkinPrev && onionSkinPrev.strokes.map((stroke, i) => (
            <Line
              key={`prev-${i}`}
              points={stroke.points}
              stroke="#ff0000"
              strokeWidth={stroke.width}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
              opacity={0.2}
            />
          ))}

          {/* Onion Skin Next */}
          {onionSkinNext && onionSkinNext.strokes.map((stroke, i) => (
            <Line
              key={`next-${i}`}
              points={stroke.points}
              stroke="#00ff00"
              strokeWidth={stroke.width}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
              opacity={0.2}
            />
          ))}

          {/* Current Drawing */}
          {drawing.strokes.map((stroke, i) => (
            <Line
              key={i}
              points={stroke.points}
              stroke={palette[stroke.colorId]?.color || '#000'}
              strokeWidth={stroke.width}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
              globalCompositeOperation={
                stroke.colorId === 'eraser' ? 'destination-out' : 'source-over'
              }
            />
          ))}
        </Layer>
      </Stage>
    </div>
  );
};
